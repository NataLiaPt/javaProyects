package adapterex;

public class EnglishDictionary {
    public String getEnglisWord(String word){
        return word;
    }
    
}
