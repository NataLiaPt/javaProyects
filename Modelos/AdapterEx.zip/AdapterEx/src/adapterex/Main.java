package adapterex;

public class Main {
    public static void main(String[] args) {
        EnglishDictionary englishDictionary = new EnglishDictionary();
        Dictionary spanishDictionary = new SpanishAdapter(englishDictionary);

        System.out.println(spanishDictionary.translate("Hello")); 
        System.out.println(spanishDictionary.translate("Adapter"));
        System.out.println(spanishDictionary.translate("Bridge")); 
        System.out.println(spanishDictionary.translate("Prototype"));
    }
}