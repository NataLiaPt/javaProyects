package adapterex;

public class SpanishAdapter implements Dictionary{
    
    private EnglishDictionary eDictionary;
   
    public SpanishAdapter (EnglishDictionary eDictionary){
        this.eDictionary = eDictionary;
    }

    @Override
    public String translate(String word) {
        if (word.equals("Hello")){
            return "Hola";
        } else if (word.equals("Adapter")){
            return "Adaptador";
        } else if (word.equals("Bridge")){
            return "Puente";
        } else if (word.equals("Prototype")){
            return "Prototipo";
        }
        return eDictionary.getEnglisWord(word);
    }
    
}