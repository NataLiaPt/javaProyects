package adapterex;

interface Dictionary {
   String translate(String word);
    
}
