package fileadapter;

public class PdfAdapter implements FileAdapter {
    private PdfFile pdfFile;
    
    public PdfAdapter(PdfFile pdfFile) {
        this.pdfFile = pdfFile;
    }
    
    @Override
    
    public String convertTo(String format) {
        
        if (format.equals("DOCX")) {
            return pdfFile.convertToDocx();
        } else if (format.equals("TXT")) {
            return pdfFile.convertToTxt();
        } else {
            return "Format not supported";
        }
    }
}

