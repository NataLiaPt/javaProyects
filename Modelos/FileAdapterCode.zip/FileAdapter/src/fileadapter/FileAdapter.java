package fileadapter;

public interface FileAdapter {
    String convertTo(String format);    
}
