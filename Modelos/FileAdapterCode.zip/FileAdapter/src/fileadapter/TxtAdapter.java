package fileadapter;

public class TxtAdapter implements FileAdapter {
    private TxtFile txtFile;

    public TxtAdapter(TxtFile txtFile) {
        this.txtFile = txtFile;
    }

    @Override
    public String convertTo(String format) {
        if (format.equals("PDF")) {
            return txtFile.convertToPdf();
        } else if (format.equals("DOCX")) {
            return txtFile.convertToDocx();
        } else {
            return "Format not supported";
        }
    }
}