package fileadapter;

public class DocxAdapter implements FileAdapter {
    
    private DocxFile docxFile;

    public DocxAdapter(DocxFile docxFile) {
        this.docxFile = docxFile;
    }

    @Override
    public String convertTo(String format) {
        if (format.equals("PDF")) {
            return docxFile.convertToPdf();
        } else if (format.equals("TXT")) {
            return docxFile.convertToTxt();
        } else {
            return "Format not supported";
        }
    }
}
