package fileadapter;

public class Main {

    public static void main(String[] args) {
        PdfFile pdfFile = new PdfFile("DiagramaClases.pdf");
        DocxFile docxFile = new DocxFile("Documentacion.docx");
        TxtFile txtFile = new TxtFile("Fuente.txt");
        
        FileAdapter pdfAdapter = FileFactory.createFileAdapter("PDF", pdfFile);
        FileAdapter docxAdapter = FileFactory.createFileAdapter("DOCX", docxFile);
        FileAdapter txtAdapter = FileFactory.createFileAdapter("TXT", txtFile);
        
        System.out.println("Convirtiendo PDF a DOCX: " + pdfAdapter.convertTo("DOCX"));
        System.out.println("Convirtiendo DOCX a TXT: " + docxAdapter.convertTo("TXT"));
        System.out.println("Convirtiendo TXT a PDF: " + txtAdapter.convertTo("PDF"));
    }
    
}
