package fileadapter;

public class DocxFile {
    private String content;

    public DocxFile(String content) {
        this.content = content;
    }

    public String convertToPdf() {
        
        return "DOCX converted to PDF: " + content;
    }

    public String convertToTxt() {
        
        return "DOCX converted to TXT: " + content;
    }
}