package fileadapter;

public class FileFactory {
    
    public static FileAdapter createFileAdapter(String fileType, Object file) {
        if (fileType.equals("PDF")) {
            return new PdfAdapter((PdfFile) file);
        } else if (fileType.equals("DOCX")) {
            return new DocxAdapter((DocxFile) file);
        } else if (fileType.equals("TXT")) {
            return new TxtAdapter((TxtFile) file);
        } else {
            return null;
        }
    }
}