package fileadapter;

public class PdfFile {
    private String content;

    public PdfFile(String content) {
        this.content = content;
    }

    public String convertToDocx() {
        
        return "PDF converted to DOCX: " + content;
    }

    public String convertToTxt() {
        
        return "PDF converted to TXT: " + content;
    }
}
