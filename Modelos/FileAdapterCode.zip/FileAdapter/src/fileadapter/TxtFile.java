package fileadapter;

public class TxtFile {
    private String content;

    public TxtFile(String content) {
        this.content = content;
    }

    public String convertToPdf() {
        
        return "TXT converted to PDF: " + content;
    }

    public String convertToDocx() {
        
        return "TXT converted to DOCX: " + content;
    }
}