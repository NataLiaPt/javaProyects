package exfacade;

public class DrinkOption {
    public void places(String drink, String date, String zone){
        System.out.println("lugares encontrados:");
        System.out.println("Para: "+ date + " En: " + zone);
        System.out.println("1. rooftop cafe");
        System.out.println("2. Local Cafe");
        System.out.println("3. Hornitos");
    }
}
