package exfacade;

public class Facade {
    private FoodOption foodOption;
    private DrinkOption drinkOption;
    
    public Facade(){
        foodOption = new FoodOption();
        drinkOption = new DrinkOption();
        }
    public void search(String food, String drink, String date, String zone){
        foodOption.restaurants(food, date, zone);
        drinkOption.places(drink, date, zone);
    }
    
}
