package exfacade;

public class FoodOption {
    public void restaurants(String food, String date, String zone){
        System.out.println("Restaurantes encontrados:");
        System.out.println("Para: "+ date + "En: " + zone);
        System.out.println("1. Corral");
        System.out.println("2. McDonalds");
        System.out.println("3. Burger Place");
    }
}
