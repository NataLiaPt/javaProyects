package exfacade;

public class Main {

    public static void main(String[] args) {
        Facade Client = new Facade();
        Client.search("Hamburguesa", "Café", "02/10/2024", "Teusaquillo");
    }
    
}
