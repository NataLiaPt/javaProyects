package prototypeejemplo;

public class PrototypeEjemplo {
    
    private Shape[] shapes;

    public PrototypeEjemplo() {
        shapes = new Shape[3];
        
        Circle circle = new Circle();
        circle.x = 10;
        circle.y = 10;
        circle.setRadius(20);
        shapes[0] = circle;
        
        Circle anotherCircle = (Circle) circle.clone();
        shapes[1] = anotherCircle;
        
        Rectangle rectangle = new Rectangle();
        rectangle.Height = 10;
        rectangle.Width = 20;
        shapes[2] = rectangle;
    }
    public void logic(){
        Shape[] shapesClone = new Shape[shapes.length];
        
        for (int i = 0; i < shapes.length; i++){
            shapesClone[i] = shapes[i].clone();
        }
        for (Shape shape : shapesClone){
            System.out.println(shape.toString());
        }
    }
    
    public static void main(String[] args) {
        PrototypeEjemplo ejemplo = new PrototypeEjemplo();
        ejemplo.logic();
    }
    
}
