package prototypeejemplo;

public class PrototypeEjemplo {

    public static void main(String[] args) {
        
    }
    
}
