package prototypeejemplo;

public class Rectangle extends Shape{
    
    public int Width;
    public int Height;

    public Rectangle(int Width, int Height, int x, int y, String Color) {
        super(x, y);
        this.Width = Width;
        this.Height = Height;
    }
    
    

    @Override
    public Rectangle clone() {
        return new Rectangle();
    }

    public int getWidth() {
        return Width;
    }

    public int getHeight() {
        return Height;
    }
    
    
}
