package prototypeejemplo;

public class Rectangle extends Shape{
    
    public int Width;
    public int Height;

    public Rectangle() {
    }

    public Rectangle(Rectangle source) {
        super(source);
        this.Width = Width;
        this.Height = Height;
    }
    
    
    @Override
    public Rectangle clone() {
        return new Rectangle(this);
    }

    @Override
    public String toString() {
        return "Rectangle{" + "Width=" + Width + ", Height=" + Height + '}';
    }

    public int getWidth() {
        return Width;
    }

    public void setWidth(int Width) {
        this.Width = Width;
    }

    public int getHeight() {
        return Height;
    }

    public void setHeight(int Height) {
        this.Height = Height;
    }
    
    
}
