package prototypeejemplo;

public abstract class Shape implements Cloneable{
    protected int x;
    protected int y;
    protected String Color;

    public Shape(int x, int y) {
        this.x = x;
        this.y = y;
        this.Color = Color;
    }
    
    public abstract Shape clone();

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    public String getColor() {
        return Color;
    }
}
